<?php
/*
开发者官网:https://ssl.goolibao.com
开发者：QQ-1032904660
发布源码资源站：y.goolibao.com
未经作者允许请不要随便修改任何内容，否则必究
*/



namespace app\index\controller;
use think\facade\View;
use think\facade\Db;
class Index
{
    public function index()
    {


     

      $mall_cateData=Db::name('mall_cate')->paginate(100);//数据表名=data
      $mallt_cateData=Db::name('mallt_cate')->paginate(100);//sslphp数据表名=data
     // 查询分类信息
    // 查询所有分类
    $categoryList = Db::name('mall_cate')->select();

    // 查询所有商品
    $goodsList = Db::name('mall_goods')->select();

    //统计所有
    $count = Db::name('mall_goods')->count();
   
 
      return view('',[
           'mall_cateData'=>$mall_cateData,
           'mallt_cateData'=>$mallt_cateData, //sslphp网址导航
           'categoryList' => $categoryList,
        'goodsList' => $goodsList,
        'count' => $count,  //统计
       ]);
  

      

   // return view();

    }

 //   public function sss()
  //  {
 //       hook('testhook', ['id'=>1]);
 //   }
// 首先，我们需要在控制器中编写查询方法


      

   // return view();

    }
   

