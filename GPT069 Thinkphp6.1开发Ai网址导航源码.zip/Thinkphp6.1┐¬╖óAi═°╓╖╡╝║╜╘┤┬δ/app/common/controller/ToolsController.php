<?php

namespace app\common\controller;

use app\BaseController;
use app\common\traits\JumpTrait;

class ToolsController extends BaseController
{
    use JumpTrait;
}
