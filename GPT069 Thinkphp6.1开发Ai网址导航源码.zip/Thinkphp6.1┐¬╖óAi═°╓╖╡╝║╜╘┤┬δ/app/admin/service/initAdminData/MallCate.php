<?php
$ul_mall_cate = array(
    array(
        "title" => "手机",
        "image" => "http://admin.demo.ulthon.com/upload/20220417/72ef1d769595627af51d76c612a789bf.png",
        "sort" => 0,
        "status" => 1,
        "remark" => "",
    )
);

return $ul_mall_cate;
