<?php
$ul_mall_tag = array(
	array(
		"id" => 1,
		"title" => "便宜",
		"create_time" => 1657347818,
		"update_time" => 1657347818,
		"delete_time" => 0
	),
	array(
		"id" => 2,
		"title" => "售后",
		"create_time" => 1657347825,
		"update_time" => 1657347825,
		"delete_time" => 0
	),
	array(
		"id" => 3,
		"title" => "黑科技",
		"create_time" => 1657347836,
		"update_time" => 1657347836,
		"delete_time" => 0
	),
	array(
		"id" => 4,
		"title" => "大厂",
		"create_time" => 1657347850,
		"update_time" => 1657347850,
		"delete_time" => 0
	)
);
return $ul_mall_tag;