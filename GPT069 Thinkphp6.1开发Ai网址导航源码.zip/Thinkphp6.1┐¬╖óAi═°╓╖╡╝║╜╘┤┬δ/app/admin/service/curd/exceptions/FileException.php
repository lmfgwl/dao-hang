<?php


namespace app\admin\service\curd\exceptions;


class FileException extends \Exception
{

}