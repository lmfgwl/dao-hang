<?php


namespace app\admin\service\curd\exceptions;


class CurdException extends \Exception
{

}