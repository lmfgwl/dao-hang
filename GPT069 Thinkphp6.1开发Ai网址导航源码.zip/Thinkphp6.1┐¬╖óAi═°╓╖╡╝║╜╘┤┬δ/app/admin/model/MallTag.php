<?php

namespace app\admin\model;

use app\common\model\TimeModel;

class MallTag extends TimeModel
{

    protected $name = "mall_tag";

    protected $deleteTime = "delete_time";

    
    
    

}