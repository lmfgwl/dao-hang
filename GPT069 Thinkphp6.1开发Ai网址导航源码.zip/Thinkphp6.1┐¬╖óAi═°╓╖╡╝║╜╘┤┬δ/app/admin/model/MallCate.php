<?php


namespace app\admin\model;


use app\common\model\TimeModel;
/**
 * 
 */
class MallCate extends TimeModel
{

    protected $deleteTime = 'delete_time';

}