<?php


namespace app\admin\model;


use app\common\model\TimeModel;

class SystemAuthNode extends TimeModel
{

    protected $autoWriteTimestamp = false;

    protected $deleteTime = false;
}