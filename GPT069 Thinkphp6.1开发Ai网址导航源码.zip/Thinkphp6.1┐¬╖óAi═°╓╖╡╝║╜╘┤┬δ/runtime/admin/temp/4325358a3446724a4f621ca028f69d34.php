<?php /*a:2:{s:59:"F:\aiVN\ulthon_admin\app\admin\view\system\quick\index.html";i:1683697861;s:55:"F:\aiVN\ulthon_admin\app\admin\view\layout\default.html";i:1683697861;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo ua_htmlentities($version); ?>" media="all">

    <link rel="stylesheet" href="/static/common/css/theme/index.css?v=<?php echo ua_htmlentities($version); ?>">

    <script>
        window.CONFIG = {
            ADMIN: "<?php echo ua_htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo ua_htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo ua_htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo ua_htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo ua_htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo ua_htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/common/js/app.js"></script>
    <script src="/static/plugs/layui-v2.8.1/layui.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
</head>

<body>
    <div class="layuimini-container">
    <div class="layuimini-main">
        <table id="currentTable" class="layui-table layui-hide"
               data-auth-add="<?php echo auth('system.quick/add'); ?>"
               data-auth-edit="<?php echo auth('system.quick/edit'); ?>"
               data-auth-delete="<?php echo auth('system.quick/delete'); ?>"
               data-auth-modify="<?php echo auth('system.quick/modify'); ?>"
               lay-filter="currentTable">
        </table>
    </div>
</div>
    <script style="display: none;" id="data-brage" type="text/plain"><?php echo (isset($data_brage) && ($data_brage !== '')?$data_brage:'[]'); ?></script>
</body>

</html>