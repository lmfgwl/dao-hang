<?php /*a:2:{s:54:"F:\aiVN\ulthon_admin\app\admin\view\index\welcome.html";i:1685552457;s:55:"F:\aiVN\ulthon_admin\app\admin\view\layout\default.html";i:1683697861;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo ua_htmlentities($version); ?>" media="all">

    <link rel="stylesheet" href="/static/common/css/theme/index.css?v=<?php echo ua_htmlentities($version); ?>">

    <script>
        window.CONFIG = {
            ADMIN: "<?php echo ua_htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo ua_htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo ua_htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo ua_htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo ua_htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo ua_htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/common/js/app.js"></script>
    <script src="/static/plugs/layui-v2.8.1/layui.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
</head>

<body>
    <link rel="stylesheet" href="/static/admin/css/welcome.css?v=<?php echo time(); ?>" media="all">
<div class="layuimini-container">
    <div class="layuimini-main">
        <div class="layui-row layui-col-space15">
            <div class="layui-col-md8">
                <div class="layui-row layui-col-space15">
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-warning icon"></i>数据统计</div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10">
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-blue">实时</span>
                                                        <h5>用户统计</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins">1234</h1>
                                                        <small>当前分类总记录数</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-cyan">实时</span>
                                                        <h5>商品统计</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins">1234</h1>
                                                        <small>当前分类总记录数</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-orange">实时</span>
                                                        <h5>浏览统计</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins">1234</h1>
                                                        <small>当前分类总记录数</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="layui-col-xs6">
                                            <div class="panel layui-bg-number">
                                                <div class="panel-body">
                                                    <div class="panel-title">
                                                        <span class="label pull-right layui-bg-green">实时</span>
                                                        <h5>订单统计</h5>
                                                    </div>
                                                    <div class="panel-content">
                                                        <h1 class="no-margins">1234</h1>
                                                        <small>当前分类总记录数</small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="layui-col-md6">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-credit-card icon icon-blue"></i>快捷入口</div>
                            <div class="layui-card-body">
                                <div class="welcome-module">
                                    <div class="layui-row layui-col-space10 layuimini-qiuck">

                                        <?php foreach($quicks as $vo): ?>
                                        <div class="layui-col-xs3 layuimini-qiuck-module">
                                            <a layuimini-content-href="<?php echo url($vo['href']); ?>" data-title="<?php echo ua_htmlentities($vo['title']); ?>">
                                                <i class="<?php echo $vo['icon']; ?>"></i>
                                                <cite><?php echo ua_htmlentities($vo['title']); ?></cite>
                                            </a>
                                        </div>
                                        <?php endforeach; ?>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="layui-col-md12">
                        <div class="layui-card">
                            <div class="layui-card-header"><i class="fa fa-line-chart icon"></i>报表统计</div>
                            <div class="layui-card-body">
                                <div id="echarts-records" style="width: 100%;min-height:500px"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="layui-col-md4">



                <div class="layui-card">
                    <div class="layui-card-header"><i class="fa fa-fire icon"></i>版本信息</div>
                    <div class="layui-card-body layui-text">
                        <table class="layui-table">
                            <colgroup>
                                <col width="100">
                                <col>
                            </colgroup>
                            <tbody>
                                <tr>
                                    <td>框架名称</td>
                                    <td data-toggle="copy-text" data-clipboard-text="ulthon_admin">
                                        ulthon_admin 框架作者http://admin.demo.ulthon.com/<i class="fa fa-copy"></i>
                                    </td>
                                </tr>







                                <td>产品名称</td>
                                <td data-toggle="copy-text" data-clipboard-text="ulthon_admin">
                                    AI网址导航，开发者QQ1032904660<i class="fa fa-copy"></i>
                                </td>
                                </tr>


                                <td>AI网址导航作者</td>
                                <td data-toggle="copy-text" data-clipboard-text="ulthon_admin">
                                    QQ1032904660 官方网址:https://ssl.goolibao.com<i class="fa fa-copy"></i>
                                </td>
                                </tr>





                                <td>源码发布</td>
                                <td data-toggle="copy-text" data-clipboard-text="ulthon_admin">
                                    https://y.goolibao.com<i class="fa fa-copy"></i>
                                </td>
                                </tr>

                                <td>源码下载</td>
                                <td data-toggle="copy-text" data-clipboard-text="ulthon_admin">
                                    https://y.goolibao.com/post-162.html<i class="fa fa-copy"></i>
                                </td>
                                </tr>







                                <tr>
                                    <td>当前版本</td>
                                    <td data-toggle="copy-text" data-clipboard-text="<?php echo \app\common\command\admin\Version::VERSION; ?>"><?php echo \app\common\command\admin\Version::VERSION; ?> <i class="fa fa-copy"></i></td>
                                </tr>
                                <tr>
                                    <td>最新修改</td>
                                    <td><?php echo implode('<br />',\app\common\command\admin\Version::COMMENT); ?></td>
                                </tr>
                                <tr>
                                    <td>主要特色</td>
                                    <td>零门槛 / 响应式 / 清爽 / 极简</td>
                                </tr>




                                <tr>

                                    <td>Layui版本</td>
                                    <td><?php echo \app\common\command\admin\Version::LAYUI_VERSION; ?></td>
                                </tr>
                                <tr>
                                    <td>ThinkPHP</td>
                                    <td><?php echo \think\App::VERSION; ?></td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>


            </div>
        </div>
    </div>
</div>
    <script style="display: none;" id="data-brage" type="text/plain"><?php echo (isset($data_brage) && ($data_brage !== '')?$data_brage:'[]'); ?></script>
</body>

</html>