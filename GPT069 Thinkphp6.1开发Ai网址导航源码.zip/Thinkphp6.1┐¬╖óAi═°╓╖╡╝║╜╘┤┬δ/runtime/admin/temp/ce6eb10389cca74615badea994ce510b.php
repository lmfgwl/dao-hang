<?php /*a:2:{s:56:"F:\aiVN\ulthon_admin\app\admin\view\mall\goods\read.html";i:1685461650;s:55:"F:\aiVN\ulthon_admin\app\admin\view\layout\default.html";i:1683697861;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo ua_htmlentities($version); ?>" media="all">

    <link rel="stylesheet" href="/static/common/css/theme/index.css?v=<?php echo ua_htmlentities($version); ?>">

    <script>
        window.CONFIG = {
            ADMIN: "<?php echo ua_htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo ua_htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo ua_htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo ua_htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo ua_htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo ua_htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/common/js/app.js"></script>
    <script src="/static/plugs/layui-v2.8.1/layui.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
</head>

<body>
    <link rel="stylesheet" href="//layui.ulthon.com/cdn/layui-ul.css">
<div class="layuimini-container">

    <div class="layui-row">
        <div class="layui-col-md8 layui-col-md-offset2 layui-col-lg6 layui-col-lg-offset3">
            <div class="ul-descriptions border">
                <div class="item">
                    <div class="label">
                        分类
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->cate->title); ?>
                    </div>
                </div>
                <div class="item short-line">
                    <div class="label">
                        标题
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->title); ?>
                    </div>
                </div>
                <div class="item poster">
                    <div class="label">
                        封面
                    </div>
                    <div class="value">
                        <img class="poster-item" src="<?php echo ua_htmlentities($row['logo']); ?>" alt="">
                    </div>
                </div>


                <!--
                <div class="item">
                    <div class="label">
                        市场价格
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->market_price); ?>
                    </div>
                </div>
                <div class="item ">
                    <div class="label">
                        折扣价格
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->discount_price); ?>
                    </div>
                </div>
                <div class="item">
                    <div class="label">
                        虚拟销量
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->virtual_sales); ?>
                    </div>
                </div>

-->




                <div class="item">
                    <div class="label">
                        添加时间
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->create_time); ?>
                    </div>
                </div>


                <!--      
               
                <div class="item">
                    <div class="label">
                        库存统计
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->total_stock); ?>
                    </div>
                </div>
                <div class="item short-line">
                    <div class="label">
                        剩余库存
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row->stock); ?>
                    </div>
                </div>

-->


                <div class="item tag line">
                    <div class="label">
                        标签
                    </div>
                    <div class="value">
                        <?php if(is_array($row->tag_list_title) || $row->tag_list_title instanceof \think\Collection || $row->tag_list_title instanceof \think\Paginator): $i = 0; $__LIST__ = $row->tag_list_title;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                        <div class="tag-item"><?php echo ua_htmlentities($vo); ?></div>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </div>
                </div>
                <div class="item line">
                    <div class="label">
                        url
                    </div>
                    <div class="value">
                        <?php echo ua_htmlentities($row['remark']); ?>
                    </div>
                </div>

                <div class="item article">
                    <div class="label">
                        详情
                    </div>
                    <div class="value">
                        <div class="article-item">
                            <?php echo ua_htmlspecialchars_decode($row['describe']); ?>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</div>
    <script style="display: none;" id="data-brage" type="text/plain"><?php echo (isset($data_brage) && ($data_brage !== '')?$data_brage:'[]'); ?></script>
</body>

</html>