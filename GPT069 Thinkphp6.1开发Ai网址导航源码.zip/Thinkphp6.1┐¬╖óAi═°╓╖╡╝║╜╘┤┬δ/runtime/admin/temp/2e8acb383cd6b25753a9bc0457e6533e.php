<?php /*a:5:{s:60:"F:\aiVN\ulthon_admin\app\admin\view\system\config\index.html";i:1683697861;s:55:"F:\aiVN\ulthon_admin\app\admin\view\layout\default.html";i:1683697861;s:59:"F:\aiVN\ulthon_admin\app\admin\view\system\config\site.html";i:1685598899;s:59:"F:\aiVN\ulthon_admin\app\admin\view\system\config\logo.html";i:1685520238;s:61:"F:\aiVN\ulthon_admin\app\admin\view\system\config\upload.html";i:1683697861;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo ua_htmlentities($version); ?>" media="all">

    <link rel="stylesheet" href="/static/common/css/theme/index.css?v=<?php echo ua_htmlentities($version); ?>">

    <script>
        window.CONFIG = {
            ADMIN: "<?php echo ua_htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo ua_htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo ua_htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo ua_htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo ua_htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo ua_htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/common/js/app.js"></script>
    <script src="/static/plugs/layui-v2.8.1/layui.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
</head>

<body>
    <div class="layuimini-container">
    <div class="layuimini-main" id="app">

        <div class="layui-tab layui-tab-brief" lay-filter="docDemoTabBrief">
            <ul class="layui-tab-title">
                <li class="layui-this">网站设置</li>
                <li>LOGO配置</li>
                <li>上传配置</li>
            </ul>
            <div class="layui-tab-content">
                <div class="layui-tab-item layui-show">
                    <form id="app-form" class="layui-form layuimini-form">
    <input type="hidden" name="group_name" value="site">
    <div class="layui-form-item">
        <label class="layui-form-label">站点名称</label>
        <div class="layui-input-block">
            <input type="text" name="site_name" class="layui-input" lay-verify="required" placeholder="请输入站点名称" value="<?php echo sysconfig('site','site_name'); ?>">
            <tip>填写站点名称。</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">网站描述</label>
        <div class="layui-input-block">
            <input type="text" name="site_description" class="layui-input" lay-verify="required" placeholder="请输入站点描述" value="<?php echo sysconfig('site','site_description'); ?>">
            <tip>写你的网站描述。</tip>
        </div>
    </div>


    <div class="layui-form-item">
        <label class="layui-form-label">SEO关键词</label>
        <div class="layui-input-block">
            <input type="text" name="site_keywords" class="layui-input" lay-verify="required" placeholder="请输入站点关键词" value="<?php echo sysconfig('site','site_keywords'); ?>">
            <tip>写你的网站关键词。</tip>
        </div>
    </div>




    <div class="layui-form-item">
        <label class="layui-form-label">浏览器图标</label>
        <div class="layui-input-block layuimini-upload">
            <input name="site_ico" class="layui-input layui-col-xs6" lay-verify="required" placeholder="请上传浏览器图标,ico类型" value="<?php echo sysconfig('site','site_ico'); ?>">
            <div class="layuimini-upload-btn">
                <span><a class="layui-btn" data-upload="site_ico" data-upload-number="one" data-upload-exts="ico"><i class="fa fa-upload"></i> 上传</a></span>
                <span><a class="layui-btn layui-btn-normal" id="select_site_ico" data-upload-select="site_ico" data-upload-number="one"><i class="fa fa-list"></i> 选择</a></span>
            </div>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">版本信息</label>
        <div class="layui-input-block">
            <input type="text" name="site_version" class="layui-input" lay-verify="required" placeholder="请输入版本信息" value="<?php echo sysconfig('site','site_version'); ?>">
            <tip>填写版本信息。</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">备案信息</label>
        <div class="layui-input-block">
            <input type="text" name="site_beian" class="layui-input" lay-verify="required" placeholder="请输入备案信息" value="<?php echo sysconfig('site','site_beian'); ?>">
            <tip>填写备案信息。</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">版权信息</label>
        <div class="layui-input-block">
            <input type="text" name="site_copyright" class="layui-input" lay-verify="required" placeholder="请输入版权信息" value="<?php echo sysconfig('site','site_copyright'); ?>">
            <tip>填写版权信息。</tip>
        </div>
    </div>


    <div class="layui-form-item">
        <label class="layui-form-label">导航颜色</label>
        <div class="layui-input-block">
            <input type="text" name="site_yanse" class="layui-input" lay-verify="required" placeholder="请输导航颜色代码" value="<?php echo sysconfig('site','site_yanse'); ?>">
            <tip>填写导航颜色代码</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">侧边导航颜色</label>
        <div class="layui-input-block">
            <input type="text" name="site_yanse2" class="layui-input" lay-verify="required" placeholder="请输导航颜色代码" value="<?php echo sysconfig('site','site_yanse2'); ?>">
            <tip>填写导航颜色代码</tip>
        </div>
    </div>




    <div class="layui-form-item">
        <label class="layui-form-label">站点域名</label>
        <div class="layui-input-block">
            <input type="text" name="site_domain" class="layui-input" lay-verify="required" placeholder="请输入站点名称" value="<?php echo sysconfig('site','site_domain'); ?>">
            <tip>填写站点域名。以http://或https://开头,内置的定时任务用到了这个配置项，修改之后需要重启定时任务</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">微博url</label>
        <div class="layui-input-block">
            <input type="text" name="site_weibourl" class="layui-input" lay-verify="required" placeholder="请输入微博url" value="<?php echo sysconfig('site','site_weibourl'); ?>">
            <tip> </tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">小红书url</label>
        <div class="layui-input-block">
            <input type="text" name="site_xiaohongshuurl" class="layui-input" lay-verify="required" placeholder="请输入小红书url" value="<?php echo sysconfig('site','site_xiaohongshuurl'); ?>">
            <tip> </tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">商务联系url</label>
        <div class="layui-input-block">
            <input type="text" name="site_shangwuurl" class="layui-input" lay-verify="required" placeholder="请输入小红书url" value="<?php echo sysconfig('site','site_shangwuurl'); ?>">
            <tip> </tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">默认密码</label>
        <div class="layui-input-block">
            <input type="text" name="site_default_password" class="layui-input" placeholder="请输入默认密码" value="<?php echo sysconfig('site','site_default_password'); ?>">
            <tip>添加账号时自动填充的密码，默认为：123456 。建议填写为您系统特有的默认密码规则，比如：ul-aa@@123</tip>
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">js脚本</label>
        <div class="layui-input-block">
            <textarea name="site_js_insert" class="layui-textarea"><?php echo sysconfig('site','site_js_insert'); ?></textarea>
            <tip>统计代码等脚本</tip>
        </div>
    </div>
    <div class="hr-line"></div>
    <div class="layui-form-item text-center">
        <button type="submit" class="layui-btn layui-btn-normal layui-btn-sm" lay-submit="system.config/save" data-refresh="false">确认</button>
        <button type="reset" class="layui-btn layui-btn-primary layui-btn-sm">重置</button>
    </div>

</form>
                </div>
                <div class="layui-tab-item">
                    <form id="app-form" class="layui-form layuimini-form">

    <div class="layui-form-item">
        <label class="layui-form-label">LOGO标题</label>
        <div class="layui-input-block">
            <input type="text" name="logo_title" class="layui-input" lay-verify="required" placeholder="请输入LOGO标题" value="<?php echo sysconfig('site','logo_title'); ?>">
            <tip>填写站点名称。</tip>
        </div>
    </div>




    <div class="layui-form-item">
        <label class="layui-form-label">LOGO图标</label>
        <div class="layui-input-block layuimini-upload">
            <input name="logo_image" class="layui-input layui-col-xs6" placeholder="请上传LOGO图标" value="<?php echo sysconfig('site','logo_image'); ?>">
            <div class="layuimini-upload-btn">
                <span><a class="layui-btn" data-upload="logo_image" data-upload-number="one" data-upload-exts="*image"><i class="fa fa-upload"></i> 上传</a></span>
                <span><a class="layui-btn layui-btn-normal" id="select_logo_image" data-upload-select="logo_image" data-upload-number="one"><i class="fa fa-list"></i> 选择</a></span>
            </div>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label">微信二维码</label>
        <div class="layui-input-block layuimini-upload">
            <input name="w_image" class="layui-input layui-col-xs6" placeholder="请上传微信二维码" value="<?php echo sysconfig('site','w_image'); ?>">
            <div class="layuimini-upload-btn">
                <span><a class="layui-btn" data-upload="w_image" data-upload-number="one" data-upload-exts="*image"><i class="fa fa-upload"></i> 上传</a></span>
                <span><a class="layui-btn layui-btn-normal" id="select_w_image" data-upload-select="w_image" data-upload-number="one"><i class="fa fa-list"></i> 选择</a></span>
            </div>
        </div>
    </div>


    <div class="layui-form-item">
        <label class="layui-form-label">微信账号二维码</label>
        <div class="layui-input-block layuimini-upload">
            <input name="wx_image" class="layui-input layui-col-xs6" placeholder="请上传微信账号二维码" value="<?php echo sysconfig('site','wx_image'); ?>">
            <div class="layuimini-upload-btn">
                <span><a class="layui-btn" data-upload="wx_image" data-upload-number="one" data-upload-exts="*image"><i class="fa fa-upload"></i> 上传</a></span>
                <span><a class="layui-btn layui-btn-normal" id="select_wx_image" data-upload-select="wx_image" data-upload-number="one"><i class="fa fa-list"></i> 选择</a></span>
            </div>
        </div>
    </div>








    <div class="hr-line"></div>
    <div class="layui-form-item text-center">
        <button type="submit" class="layui-btn layui-btn-normal layui-btn-sm" lay-submit="system.config/save" data-refresh="false">确认</button>
        <button type="reset" class="layui-btn layui-btn-primary layui-btn-sm">重置</button>
    </div>

</form>
                </div>
                <div class="layui-tab-item">
                    <form id="app-form" class="layui-form layuimini-form show-type">
    <input type="hidden" name="group_name" value="upload">
    <div class="layui-form-item">
        <label class="layui-form-label required">存储方式</label>
        <div class="layui-input-block">
            <?php foreach(['local_public'=>'本地存储','alioss'=>'阿里云oss','qnoss'=>'七牛云oss','txcos'=>'腾讯云cos'] as $key=>$val): ?>
            <input type="radio" name="upload_type" lay-filter="upload_type" value="<?php echo ua_htmlentities($key); ?>" title="<?php echo ua_htmlentities($val); ?>" <?php if($key==sysconfig('upload','upload_type')): ?>checked="" <?php endif; ?>>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label required">允许类型</label>
        <div class="layui-input-block">
            <input type="text" name="upload_allow_ext" class="layui-input" lay-verify="required" lay-reqtext="请输入允许类型" placeholder="请输入允许类型" value="<?php echo sysconfig('upload','upload_allow_ext'); ?>">
            <tip>英文逗号做分隔符。</tip>
        </div>
    </div>

    <div class="layui-form-item">
        <label class="layui-form-label required">允许大小</label>
        <div class="layui-input-block">
            <input type="text" name="upload_allow_size" class="layui-input" lay-verify="required" lay-reqtext="请输入允许上传大小" placeholder="请输入允许上传大小" value="<?php echo sysconfig('upload','upload_allow_size'); ?>">
            <tip>设置允许上传大小。</tip>
        </div>
    </div>
    <div class="layui-form-item show-type-item local_public">
        <label class="layui-form-label">站点域名</label>
        <div class="layui-input-block">
            <input type="text" name="local_domain" class="layui-input" placeholder="请输入站点域名" value="<?php echo sysconfig('upload','local_domain'); ?>">
            <tip>例子：<?php echo ua_htmlentities(app('request')->domain()); ?>，如果不填写，那么自动获取当前站点域名，但是在命令行调用上传时不能正确生成地址。</tip>
        </div>
    </div>
    <div class="layui-form-item show-type-item alioss">
        <label class="layui-form-label required">公钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="alioss_access_key_id" class="layui-input" lay-verify="required" lay-reqtext="请输入公钥信息" placeholder="请输入公钥信息" value="<?php echo sysconfig('upload','alioss_access_key_id'); ?>">
            <tip>例子：FSGGshu64642THSk</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item alioss">
        <label class="layui-form-label required">私钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="alioss_access_key_secret" class="layui-input" lay-verify="required" lay-reqtext="请输入私钥信息" placeholder="请输入私钥信息" value="<?php echo sysconfig('upload','alioss_access_key_secret'); ?>">
            <tip>例子：5fsfPReYKkFSGGshu64642THSkmTInaIm</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item alioss">
        <label class="layui-form-label required">数据中心</label>
        <div class="layui-input-block">
            <input type="text" name="alioss_endpoint" class="layui-input" lay-verify="required" lay-reqtext="请输入数据中心" placeholder="请输入数据中心" value="<?php echo sysconfig('upload','alioss_endpoint'); ?>">
            <tip>例子：https://oss-cn-shenzhen.aliyuncs.com</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item alioss">
        <label class="layui-form-label required">空间名称</label>
        <div class="layui-input-block">
            <input type="text" name="alioss_bucket" class="layui-input" lay-verify="required" lay-reqtext="请输入空间名称" placeholder="请输入空间名称" value="<?php echo sysconfig('upload','alioss_bucket'); ?>">
            <tip>例子：ulthon-admin</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item alioss">
        <label class="layui-form-label required">访问域名</label>
        <div class="layui-input-block">
            <input type="text" name="alioss_domain" class="layui-input" lay-verify="required" lay-reqtext="请输入访问域名" placeholder="请输入访问域名" value="<?php echo sysconfig('upload','alioss_domain'); ?>">
            <tip>例子：ulthon-admin.oss-cn-shenzhen.aliyuncs.com</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">APPID</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_appid" class="layui-input" lay-verify="required" lay-reqtext="请输入APPID" placeholder="请输入APPID" value="<?php echo sysconfig('upload','txcos_appid'); ?>">
            <tip>开发者访问 COS 服务时拥有的用户维度唯一资源标识，用以标识资源，可在 API 密钥管理 页面获取</tip>
        </div>
    </div>
    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">公钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_secret_id" class="layui-input" lay-verify="required" lay-reqtext="请输入公钥信息" placeholder="请输入公钥信息" value="<?php echo sysconfig('upload','txcos_secret_id'); ?>">
            <tip>例子：AKIDta6OQCbALQGrCI6ngKwQffR3dfsfrwrfs</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">私钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_secret_key" class="layui-input" lay-verify="required" lay-reqtext="请输入私钥信息" placeholder="请输入私钥信息" value="<?php echo sysconfig('upload','txcos_secret_key'); ?>">
            <tip>例子：VllEWYKtClAbpqfFdTqysXxGQM6dsfs</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">存储桶地域</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_region" class="layui-input" lay-verify="required" lay-reqtext="请输入存储桶地域" placeholder="请输入存储桶地域" value="<?php echo sysconfig('upload','txcos_region'); ?>">
            <tip>例子：ap-guangzhou</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">存储桶名称</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_bucket" class="layui-input" lay-verify="required" lay-reqtext="请输入存储桶名称" placeholder="请输入存储桶名称" value="<?php echo sysconfig('upload','txcos_bucket'); ?>">
            <tip>例子：ulthon-admin-1251997243</tip>
        </div>
    </div>
    <div class="layui-form-item show-type-item txcos">
        <label class="layui-form-label required">访问域名</label>
        <div class="layui-input-block">
            <input type="text" name="txcos_domain" class="layui-input" lay-verify="required" lay-reqtext="请输入访问域名" placeholder="请输入访问域名" value="<?php echo sysconfig('upload','txcos_domain'); ?>">
            <tip>例子：https://xh-1255063857.cos.ap-chengdu.myqcloud.com</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item qnoss">
        <label class="layui-form-label required">公钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="qnoss_access_key" class="layui-input" lay-verify="required" lay-reqtext="请输入公钥信息" placeholder="请输入公钥信息" value="<?php echo sysconfig('upload','qnoss_access_key'); ?>">
            <tip>例子：v-lV3tXev7yyfsfa1jRc6_8rFOhFYGQvvjsAQxdrB</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item qnoss">
        <label class="layui-form-label required">私钥信息</label>
        <div class="layui-input-block">
            <input type="text" name="qnoss_secret_key" class="layui-input" lay-verify="required" lay-reqtext="请输入私钥信息" placeholder="请输入私钥信息" value="<?php echo sysconfig('upload','qnoss_secret_key'); ?>">
            <tip>例子：XOhYRR9JNqxsWVEO-mHWB4193vfsfsQADuORaXzr</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item qnoss">
        <label class="layui-form-label required">存储空间</label>
        <div class="layui-input-block">
            <input type="text" name="qnoss_bucket" class="layui-input" lay-verify="required" lay-reqtext="请输入存储桶地域" placeholder="请输入存储桶地域" value="<?php echo sysconfig('upload','qnoss_bucket'); ?>">
            <tip>例子：ulthon-admin</tip>
        </div>
    </div>

    <div class="layui-form-item show-type-item qnoss">
        <label class="layui-form-label required">访问域名</label>
        <div class="layui-input-block">
            <input type="text" name="qnoss_domain" class="layui-input" lay-verify="required" lay-reqtext="请输入访问域名" placeholder="请输入访问域名" value="<?php echo sysconfig('upload','qnoss_domain'); ?>">
            <tip>例子：http://q0xqzappp.bkt.clouddn.com</tip>
        </div>
    </div>

    <div class="hr-line"></div>
    <div class="layui-form-item text-center">
        <button type="submit" class="layui-btn layui-btn-normal layui-btn-sm" lay-submit="system.config/save" data-refresh="false">确认</button>
        <button type="reset" class="layui-btn layui-btn-primary layui-btn-sm">重置</button>
    </div>

</form>
<script>
    var upload_type = "<?php echo sysconfig('upload','upload_type'); ?>";
</script>
                </div>
            </div>
        </div>

    </div>
</div>
    <script style="display: none;" id="data-brage" type="text/plain"><?php echo (isset($data_brage) && ($data_brage !== '')?$data_brage:'[]'); ?></script>
</body>

</html>