<?php /*a:2:{s:57:"F:\aiVN\ulthon_admin\app\admin\view\index\edit_admin.html";i:1683697861;s:55:"F:\aiVN\ulthon_admin\app\admin\view\layout\default.html";i:1683697861;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title><?php echo sysconfig('site','site_name'); ?></title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <link rel="stylesheet" href="/static/admin/css/public.css?v=<?php echo ua_htmlentities($version); ?>" media="all">

    <link rel="stylesheet" href="/static/common/css/theme/index.css?v=<?php echo ua_htmlentities($version); ?>">

    <script>
        window.CONFIG = {
            ADMIN: "<?php echo ua_htmlentities((isset($adminModuleName) && ($adminModuleName !== '')?$adminModuleName:'admin')); ?>",
            CONTROLLER_JS_PATH: "<?php echo ua_htmlentities((isset($thisControllerJsPath) && ($thisControllerJsPath !== '')?$thisControllerJsPath:'')); ?>",
            ACTION: "<?php echo ua_htmlentities((isset($thisAction) && ($thisAction !== '')?$thisAction:'')); ?>",
            AUTOLOAD_JS: "<?php echo ua_htmlentities((isset($autoloadJs) && ($autoloadJs !== '')?$autoloadJs:'false')); ?>",
            IS_SUPER_ADMIN: "<?php echo ua_htmlentities((isset($isSuperAdmin) && ($isSuperAdmin !== '')?$isSuperAdmin:'false')); ?>",
            VERSION: "<?php echo ua_htmlentities((isset($version) && ($version !== '')?$version:'1.0.0')); ?>",
            CSRF_TOKEN: "<?php echo token(); ?>",
        };
    </script>
    <script src="/static/common/js/app.js"></script>
    <script src="/static/plugs/layui-v2.8.1/layui.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/plugs/require-2.3.6/require.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
    <script src="/static/config-admin.js?v=<?php echo ua_htmlentities($version); ?>" charset="utf-8"></script>
</head>

<body>
    <div class="layuimini-container">
    <div class="layuimini-main">

        <form id="app-form" class="layui-form layuimini-form">

            <div class="layui-form-item">
                <label class="layui-form-label required">用户头像</label>
                <div class="layui-input-block layuimini-upload">
                    <input name="head_img" class="layui-input layui-col-xs6" lay-reqtext="请上传用户头像" placeholder="请上传用户头像" value="<?php echo ua_htmlentities((isset($row['head_img']) && ($row['head_img'] !== '')?$row['head_img']:'')); ?>">
                    <div class="layuimini-upload-btn">
                        <span><a class="layui-btn" data-upload="head_img" data-upload-number="one" data-upload-exts="*image"><i class="fa fa-upload"></i> 上传</a></span>
                        <span><a class="layui-btn layui-btn-normal" id="select_head_img" data-upload-select="head_img" data-upload-number="one"><i class="fa fa-list"></i> 选择</a></span>
                    </div>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label required">登录账户</label>
                <div class="layui-input-block">
                    <input type="text" name="username" class="layui-input" readonly value="<?php echo ua_htmlentities((isset($row['username']) && ($row['username'] !== '')?$row['username']:'')); ?>">
                    <tip>填写登录账户。</tip>
                </div>
            </div>

            <div class="layui-form-item">
                <label class="layui-form-label">用户手机</label>
                <div class="layui-input-block">
                    <input type="text" name="phone" class="layui-input" lay-reqtext="请输入用户手机" placeholder="请输入用户手机" value="<?php echo ua_htmlentities((isset($row['phone']) && ($row['phone'] !== '')?$row['phone']:'')); ?>">
                    <tip>填写用户手机。</tip>
                </div>
            </div>

            <div class="layui-form-item layui-form-text">
                <label class="layui-form-label">备注信息</label>
                <div class="layui-input-block">
                    <textarea name="remark" class="layui-textarea" placeholder="请输入备注信息"><?php echo ua_htmlentities((isset($row['remark']) && ($row['remark'] !== '')?$row['remark']:'')); ?></textarea>
                </div>
            </div>

            <div class="hr-line"></div>
            <div class="layui-form-item text-center">
                <button type="submit" class="layui-btn layui-btn-normal layui-btn-sm" lay-submit>确认</button>
                <button type="reset" class="layui-btn layui-btn-primary layui-btn-sm">重置</button>
            </div>

        </form>

    </div>
</div>
    <script style="display: none;" id="data-brage" type="text/plain"><?php echo (isset($data_brage) && ($data_brage !== '')?$data_brage:'[]'); ?></script>
</body>

</html>